classdef GripperTM5 < RobotBaseClass
    %% UR3 Universal Robot 3kg payload robot model
    %
    % WARNING: This model has been created by UTS students in the subject
    % 41013. No guarentee is made about the accuracy or correctness of the
    % of the DH parameters of the accompanying ply files. Do not assume
    % that this matches the real robot!
    
    properties(Access = public)   
        plyFileNameStem = 'GripperTM5';
    
    end
  
    methods
%% Define robot Function 
        function self = GripperTM5(baseTr)
			self.CreateModel();
            if nargin < 1			
				baseTr = eye(4);				
            end
            self.model.base = self.model.base.T * baseTr * trotx(0) * troty(pi/2);

            self.PlotAndColourRobot();         
        end
%% CreateModel
        function CreateModel(self)
            % link(1) = Link('d',0.027458,'a',-0.051344,'alpha',0,'qlim',deg2rad([-360 360]), 'offset',0);
            link(1) = Link('d',0,'a',-0.051344,'alpha',0,'qlim',deg2rad([-5 95]), 'offset',0);
            link(2) = Link('d',0,'a',-0.001344,'alpha',0,'qlim', deg2rad([-10 75]), 'offset',pi/12);
            link(3) = Link('d',0,'a',-0.032536,'alpha',0,'qlim',deg2rad(0), 'offset',0);
            link(4) = Link('d',0.0025536,'a',0,'alpha',0,'qlim',deg2rad([-5 75]), 'offset',0); 
            link(5) = Link('d',0,'a',-0.022536,'alpha',0,'qlim',deg2rad(0), 'offset',0);
           
            self.model = SerialLink(link,'name',self.name);
        end      
    end
end
