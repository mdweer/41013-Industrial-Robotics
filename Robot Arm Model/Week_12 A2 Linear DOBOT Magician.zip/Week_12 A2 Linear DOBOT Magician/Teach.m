r = LinearDM;
q0 = r.model.getpos();
r.model.teach(q0);
clc