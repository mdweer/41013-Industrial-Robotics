classdef LinearDM < RobotBaseClass
    %% LinearUR5 UR5 on a non-standard linear rail created by a student

    properties(Access = public)              
        plyFileNameStem = 'LinearDM';
    end
    
    methods
%% Define robot Function 
function self = LinearDM(baseTr)
			self.CreateModel();
            if nargin < 1			
				baseTr = eye(4);				
            end
            self.model.base = self.model.base.T * baseTr * trotx(pi/2) * troty(pi/2);
            
            self.PlotAndColourRobot();         
        end

%% Create the robot model
        function CreateModel(self)   
            link(1) = Link([pi    0           0        pi/2    1]); % PRISMATIC Link  
            link(2) = Link('d',0.145198,'a',0,'alpha',pi/2,'qlim',deg2rad(0), 'offset', 0);

            link(1).qlim = [-1 0];
            
            self.model = SerialLink(link,'name',self.name);
        end
     
    end
end
