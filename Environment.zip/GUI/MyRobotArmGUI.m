classdef MyRobotArmGUI < matlab.apps.AppBase

    % Properties that correspond to app components
    properties (Access = public)
        UIFigure       matlab.ui.Figure
        SliderJoint1   matlab.ui.control.Slider
        SliderJoint2   matlab.ui.control.Slider
        %... Add other joints as needed
    end

    properties (Access = private)
        armController  % Instance of ArmController class
    end

    % Callbacks that handle component events
    methods (Access = private)

        % Code that executes after component creation
        function startupFcn(app)
     
            stepsPerMetre = 50;  % Example value, adjust as necessary
            ikErrorMax = 1e-3;  % Example value, adjust as necessary
            velocityMax = 0.1;  % Example value, adjust as necessary
            qInit = zeros(1, robotModel.n);  % Replace with the actual number of joints in your robot
            
            app.armController = ArmController( stepsPerMetre, ikErrorMax, velocityMax, qInit);
            % Set sliders initial values;;
            qInit = app.armController.qCurrent;
            app.SliderJoint1.Value = qInit(1);
            app.SliderJoint2.Value = qInit(2);
            %... Initialize other joints as needed
        end

        % Value changed function: SliderJoint1
        function SliderJoint1ValueChanged(app, ~)
            value = app.SliderJoint1.Value;
            app.updateRoboticArm(1, value);
        end

        % Value changed function: SliderJoint2
        function SliderJoint2ValueChanged(app, event)
            value = app.SliderJoint2.Value;
            app.updateRoboticArm(2, value);
        end

        %... Add callback functions for other joints as needed
    end

    % App creation and deletion
    methods (Access = public)

        % Construct app
        function app = MyRobotArmGUI

            % Create UIFigure and components
            createComponents(app)

            % Register the app with App Designer
            registerApp(app, app.UIFigure)

            % Execute the startup function
            runStartupFcn(app, @startupFcn)
        end

        % Code that executes before app deletion
        function delete(app)

            % Delete UIFigure when app is deleted
            delete(app.UIFigure)
        end
    end

    % Component initialization
    methods (Access = private)

        % Create UIFigure and components
        function createComponents(app)

            % Create UIFigure and hide until all components are created
            app.UIFigure = uifigure('Visible', 'off');
            app.UIFigure.Position = [100 100 640 480];
            app.UIFigure.Name = 'MATLAB App';

            % Create SliderJoint1
            app.SliderJoint1 = uislider(app.UIFigure);
            app.SliderJoint1.Limits = [-pi pi];  % Set according to joint limits
            app.SliderJoint1.ValueChangedFcn = createCallbackFcn(app, @SliderJoint1ValueChanged, true);
            app.SliderJoint1.Position = [150 400 150 3];

            % Create SliderJoint2
            app.SliderJoint2 = uislider(app.UIFigure);
            app.SliderJoint2.Limits = [-pi pi];  % Set according to joint limits
            app.SliderJoint2.ValueChangedFcn = createCallbackFcn(app, @SliderJoint2ValueChanged, true);
            app.SliderJoint2.Position = [150 350 150 3];

            %... Add other UI components as needed

            % Show the figure after all components are created
            app.UIFigure.Visible = 'on';
        end
    end

    % App-specific functions
    methods (Access = private)
        
        % Update the robotic arm based on slider values
        function updateRoboticArm(app, jointIndex, jointAngle)
            % Get current joint angles
            q = app.armController.qCurrent;
            
            % Update the specific joint angle
            q(jointIndex) = jointAngle;
            
            % Update the robotic arm
            app.armController.robot.model.animate(q);
            
            % Update other necessary components or visuals if needed
            % ...
        end
    end
end
