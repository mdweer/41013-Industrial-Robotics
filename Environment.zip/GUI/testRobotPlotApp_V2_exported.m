classdef testRobotPlotApp_V2_exported < matlab.apps.AppBase

    % Properties that correspond to app components
    properties (Access = public)
        figure1                   matlab.ui.Figure
        MakeLoadedDobotMoveButton matlab.ui.control.Button
        SliderJoint1              matlab.ui.control.Slider
        plot                      matlab.ui.control.UIAxes
    end

    properties (Access = public)
        ctrlDobot ArmController
        ctrlTM5 ArmController
    end

    properties (Access = private)
        modelDobotMagician % Where I will put the loaded Dobot Magician
        qDobotHome = [0, pi/4, pi/4, 0, 0]; % Home position for Dobot Magician
    end



    % Callbacks that handle component events
    methods (Access = private)

        % Code that executes after component creation
        function init(app, varargin)
            % Code to run once GUI is loaded successfully
            ax = gca;

            baseTr{1} = eye(4) * transl(0.25,0,0) * trotz(180,'deg');
            baseTr{2} = eye(4) * transl(-0.6,0,0) * trotz(180,'deg');
            app.ctrlDobot = ArmController(DobotMagician(baseTr{1}));

            app.ctrlTM5 = ArmController(TM5(baseTr{2}));
            app.modelDobotMagician = DobotMagician();
            app.modelDobotMagician.model.base = transl([0, -0.5, 0]);
            app.modelDobotMagician.model.animate(app.qDobotHome);
            
            drawnow();

            for i = size(ax.Children,1):-1:1
                if strcmp(ax.Children(i).Type,'surface')
                    delete(ax.Children(i));
                end
            end

            % Set up SliderJoint1
            app.SliderJoint1.Limits = app.modelDobotMagician.model.qlim(1,:);
            app.SliderJoint1.Value = app.qDobotHome(1);
            app.SliderJoint1.ValueChangedFcn = createCallbackFcn(app, @updateRobot, true);

            app.MakeLoadedDobotMoveButton.Enable = true;
        end

        function MakeLoadedDobotMoveButtonPushed(app, event)
            qMatrix = jtraj(app.qDobotHome, app.modelDobotMagician.model.qlim(:,1)', 20);
            for robotStepIndex = 1:size(qMatrix, 1)
                app.modelDobotMagician.model.animate(qMatrix(robotStepIndex, :));
                drawnow;
            end
        end

        function updateRobot(app, ~)
            % Get current joint angles
            qCurrent = app.modelDobotMagician.model.getpos();
            
            % Update joint angles based on sliders
            qCurrent(1) = app.SliderJoint1.Value;
            
            % Animate robot
            app.modelDobotMagician.model.animate(qCurrent);
        end
    end

    % Component initialization
    methods (Access = private)

        % Create UIFigure and components
        function createComponents(app)

            % Create figure1 and hide until all components are created
            app.figure1 = uifigure('Visible', 'off');
            app.figure1.Position = [100 100 812 560];
            app.figure1.Name = 'TestRobotPlot_V2';
            app.figure1.HandleVisibility = 'callback';
            app.figure1.Tag = 'figure1';

            % Create SliderJoint1
            app.SliderJoint1 = uislider(app.figure1);
            app.SliderJoint1.Position = [100, 450, 150, 3];

            % Create plot
            app.plot = uiaxes(app.figure1);
            xlabel(app.plot, 'X');
            ylabel(app.plot, 'Y');
            app.plot.FontSize = 12;
            app.plot.NextPlot = 'replace';
            app.plot.Tag = 'axes1';
            app.plot.Position = [297 101 445 360];
            
            % Create MakeLoadedDobotMoveButton
            app.MakeLoadedDobotMoveButton = uibutton(app.figure1, 'push');
            app.MakeLoadedDobotMoveButton.ButtonPushedFcn = createCallbackFcn(app, @MakeLoadedDobotMoveButtonPushed, true);
            app.MakeLoadedDobotMoveButton.Position = [89, 150, 148, 23];
            app.MakeLoadedDobotMoveButton.Text = 'Make Loaded Dobot Move';

            % Show the figure after all components are created
            app.figure1.Visible = 'on';
        end
    end
    
    % App creation and deletion
    methods (Access = public)

        % Construct app
        function app = testRobotPlotApp_V2_exported(varargin)

            runningApp = getRunningApp(app);

            % Check for running singleton app
            if isempty(runningApp)

                % Create UIFigure and components
                createComponents(app)

                % Register the app with App Designer
                registerApp(app, app.figure1)

                % Execute the startup function
                runStartupFcn(app, @(app)init(app, varargin{:}))
            else

                % Focus the running singleton app
                figure(runningApp.figure1)

                app = runningApp;
            end

            if nargout == 0
                clear app
            end
        end

        % Code that executes before app deletion
        function delete(app)

            % Delete UIFigure when app is deleted
            delete(app.figure1)
        end
    end
        methods (Access = public)
            function setJoint1Position(app, jointAngles)
                app.ctrlDobot.SetQ(jointAngles);
                app.SliderJoint1.Value = jointAngles(1);
                updateRobot(app);  % Call the update method to reflect the changes
            end
        end
end

