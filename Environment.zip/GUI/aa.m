classdef aa < matlab.apps.AppBase

    % Properties that correspond to app components
    properties (Access = public)
        UIFigure                 matlab.ui.Figure
        MakeLoadedDobotMoveButton matlab.ui.control.Button
        MakeLoadedTM5MoveButton  matlab.ui.control.Button
        UIAxes                   matlab.ui.control.UIAxes
    end

    
    properties (Access = private)
        ctrlDobot                % Instance of ArmController for Dobot
        ctrlTM5                  % Instance of ArmController for TM5
        qz = [0 0 0 0 0 0];      % Initial joint positions for both robots
    end
    

    % Callbacks that handle component events
    methods (Access = private)

        % Code that executes after component creation
        function startupFcn(app)
            % Code to run once GUI is loaded successfully
            
            % Initialize Dobot ArmController
            baseTrDobot = eye(4) * transl(0.2, 0, 0) * trotz(180, 'deg');
            app.ctrlDobot = ArmController(DobotMagician(baseTrDobot));
            app.ctrlDobot.model.plot(app.qz, 'workspace', [-2 2 -2 2 -0.5 2]);
            hold(app.UIAxes, 'on');

            % Initialize TM5 ArmController
            baseTrTM5 = eye(4) * transl(-0.6, 0, 0) * trotz(180, 'deg');
            app.ctrlTM5 = ArmController(TM5(baseTrTM5));
            app.ctrlTM5.model.plot(app.qz, 'workspace', [-2 2 -2 2 -0.5 2]);

            % Enable the move buttons
            app.MakeLoadedDobotMoveButton.Enable = true;
            app.MakeLoadedTM5MoveButton.Enable = true;
        end

        % Button pushed function: MakeLoadedDobotMoveButton
        function MakeLoadedDobotMoveButtonPushed(app, event)
            % Add code here to move the Dobot using app.ctrlDobot
        end

        % Button pushed function: MakeLoadedTM5MoveButton
        function MakeLoadedTM5MoveButtonPushed(app, event)
            % Add code here to move the TM5 using app.ctrlTM5
        end
    end

    % Component initialization
    methods (Access = private)

        % Create UIFigure and components
        function createComponents(app)

            % Create UIFigure and hide until all components are created
            app.UIFigure = uifigure('Visible', 'off');
            app.UIFigure.Position = [100 100 812 560];
            app.UIFigure.Name = 'MATLAB App';
            app.UIFigure.HandleVisibility = 'callback';

            % Create MakeLoadedDobotMoveButton
            app.MakeLoadedDobotMoveButton = uibutton(app.UIFigure, 'push');
            app.MakeLoadedDobotMoveButton.ButtonPushedFcn = createCallbackFcn(app, @MakeLoadedDobotMoveButtonPushed, true);
            app.MakeLoadedDobotMoveButton.Position = [85 321 155 23];
            app.MakeLoadedDobotMoveButton.Text = 'Make Loaded Dobot Move';

            % Create MakeLoadedTM5MoveButton
            app.MakeLoadedTM5MoveButton = uibutton(app.UIFigure, 'push');
            app.MakeLoadedTM5MoveButton.ButtonPushedFcn = createCallbackFcn(app, @MakeLoadedTM5MoveButtonPushed, true);
            app.MakeLoadedTM5MoveButton.Position = [89 236 148 23];
            app.MakeLoadedTM5MoveButton.Text = 'Make Loaded TM5 Move';

            % Create UIAxes
            app.UIAxes = axes(app.UIFigure);
            xlabel(app.UIAxes, 'X')
            ylabel(app.UIAxes, 'Y')
            app.UIAxes.Position = [297 101 445 360];

            % Show the figure after all components are created
            app.UIFigure.Visible = 'on';
        end
    end

    % App creation and deletion
    methods (Access = public)

        % Construct app
        function app = testRobotPlotApp_V2_exported(varargin)
            % Create UIFigure and components
            createComponents(app)

            % Execute the startup function
            runStartupFcn(app, @(app)startupFcn(app, varargin{:}));
        end

        % Code that executes before app deletion
        function delete(app)

            % Delete UIFigure when app is deleted
            delete(app.UIFigure)
        end
    end
end
