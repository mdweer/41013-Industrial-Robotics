classdef armState
    enumeration
        Init
        MovingToNextPose
        WaitingForNextPose
        EStop
    end %Arm states
end
