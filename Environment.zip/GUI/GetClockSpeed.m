function [ClkSpeed] = GetClockSpeed()
    global CLOCK_SPEED;
    ClkSpeed = CLOCK_SPEED;
end