function SetPairCount(PairCount)
    global BASKET_BALL_COUNT;
    BASKET_BALL_COUNT = PairCount;
end