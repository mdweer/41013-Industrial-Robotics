function [FloorHeight] = GetWorkspaceFloor()
    global WORKSPACE_FLOOR;
    FloorHeight = WORKSPACE_FLOOR;
end