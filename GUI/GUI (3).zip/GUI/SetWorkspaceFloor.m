function SetWorkspaceFloor(FloorHeight)
    global WORKSPACE_FLOOR;
    WORKSPACE_FLOOR = FloorHeight;
end