a = arduino('COM3', 'Uno');

configurePin(a, 'D2', 'pullup');

buttonState = readDigitalPin(a, 'D2');


if buttonState == 0
    disp('Button pressed');
else
    disp('Button not pressed');
end

clear a
