function [PairCount] = GetPairCount()
    global BASKET_BALL_COUNT;
    PairCount = BASKET_BALL_COUNT;
end