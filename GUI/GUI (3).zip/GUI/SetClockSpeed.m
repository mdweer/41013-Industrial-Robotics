function SetClockSpeed(ClkSpeed)
    global CLOCK_SPEED;
    CLOCK_SPEED = ClkSpeed;
end